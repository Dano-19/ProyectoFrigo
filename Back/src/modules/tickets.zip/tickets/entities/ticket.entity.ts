import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn, UpdateDateColumn, ManyToOne, OneToMany } from 'typeorm';
import { User } from '../../users/entities/user.entity'; // Ajusta la ruta según tu estructura de proyecto
import { Reporte } from '../../reporte/entities/cliente.entity';

@Entity('tickets')
export class Ticket {
    @PrimaryGeneratedColumn('uuid')
    id: string;

    @Column({ type: 'varchar', length: 255 })
    title: string;

    @Column({ type: 'text' })
    description: string;

    @Column({ type: 'varchar', length: 50 })
    status: string;

    @ManyToOne(() => User, (user) => user.tickets, { nullable: false })
    assignedTo: User;

    @OneToMany(() => Reporte, reporte => reporte.ticket)
    reportes: Reporte[];

    @CreateDateColumn()
    createdAt: Date;

    @UpdateDateColumn()
    updatedAt: Date;
}